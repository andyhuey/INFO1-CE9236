//
//  HelloTests.h
//  HelloTests
//
//  Created by Andrew Huey on 10/17/11.
//  Copyright 2011 EVI. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface HelloTests : SenTestCase

@end

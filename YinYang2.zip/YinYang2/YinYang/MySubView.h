//
//  MySubView.h
//  YinYang
//
//  Created by Andrew Huey on 10/31/11.
//  Copyright (c) 2011 EVI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MySubView : UIView {
    BOOL firstTime;
}

@end

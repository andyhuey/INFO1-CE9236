//
//  YinYangTests.h
//  YinYangTests
//
//  Created by Andrew Huey on 10/24/11.
//  Copyright (c) 2011 EVI. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface YinYangTests : SenTestCase

@end
